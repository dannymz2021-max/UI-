# UI工作室 / AI创作台 — 本地续作交接包

**交接日期：2026-11-03**  
**当前公开站点：** https://layerlab-studio-dany.xpbet-3575.chatgpt.site  
**已有线上版本：** UI工作室 V6（依据 2026-11-02 的 Sites 发布记录）  
**下一阶段目标：** 将原有 Icon 工作台和 AI 图片生成入口合并为「AI创作台」。

## 重要声明：本包不是原站完整源码

本会话当前可用的执行环境**没有挂载原 Sites 项目的源码目录**，Sites 源码仓库接口也未向本次执行环境开放。此前聊天中出现的 `/workspace/scratch/2c8e34d3416f/layerlab/` 是**先前执行环境**的路径，当前无法直接读取；不能假定该目录已在本机存在。

因此，此 ZIP 提供的是**可以真正用于本地 ChatGPT 继续工作的交接包**，包含项目背景、功能状态、产品需求、Figma 与素材链接、安全接入条件、验收清单、用户上传的参考图、早期界面截图和下一轮工作提示，**不包含真实项目的 src/app/pages/public 等完整源码，也不应替代源代码仓库的备份**。

在本地继续开发**原站**时，请先从原 Sites 工程/原创建会话导出完整源代码（含项目内 `package.json`、源码、public 资源、lockfile 和构建配置），再放进 `project-source-PLACEHOLDER/` 或单独解压到项目目录。`docs/SOURCE_RECOVERY.md` 说明恢复方法。

## 先看哪些文件

1. `docs/PROJECT_HANDOFF.md`：项目背景、现状、下一阶段边界、API 与风险。
2. `docs/NEXT_CHAT_PROMPT.md`：在本地 ChatGPT 中直接粘贴的续作指令。
3. `docs/SOURCE_RECOVERY.md`：怎样取得真正的原站源码、如何核对完整性。
4. `docs/IMPLEMENTATION_CHECKLIST.md`：具体实现步骤和验收用例。
5. `docs/PROJECT_HANDOFF.docx`：与 Markdown 同主题的正式交接文档。
6. `references/`：当前会话可验证的参考图和历史截图（不是完整素材库）。
7. `ARCHIVE_MANIFEST.json`：打包来源、内容范围和完整性信息。

## 使用方式

在本地 ChatGPT 中上传此 ZIP，并说：

> 请阅读根目录的 README_FIRST.md 和 docs/NEXT_CHAT_PROMPT.md。先核对真实源代码是否已经包含在上传材料中；如果缺失，不要编造原站源码。等我加入完整源码后，按交接文档将 Icon 工作台与 AI 图片生成合并成一个真实调用模型的「AI创作台」，保留原有主站 UI、活动 UI 与拆层功能。

## 安全

- 本包不包含 API Key、临时 Sites 凭据、登录令牌或 `.env` 实际值。
- 公开站点启用真实生图前，必须做服务端鉴权、限额与滥用防护。
- 使用者拥有 ChatGPT 订阅，不等于网站可以使用同一账号的 ChatGPT 生图额度；网站需图像 API 或获授权的公司服务。
