# 如何恢复 UI工作室真正完整的源码

## 已知定位信息

- 项目名：UI工作室（LayerLab）
- 公开 URL：https://layerlab-studio-dany.xpbet-3575.chatgpt.site
- Sites project ID：`appgprj_6adf2c4fd9ec8191b6f1b79b16bdd2c1`
- 最后记录版本：V6 / `appgprj_6adf2c4fd9ec8191b6f1b79b16bdd2c1~appgver_bcfb56bd3b2c81919469d3c5a743742c`
- 私有源仓库地址（不含访问凭据）：`https://git.chatgpt-team.site/b18af9ac-497e-4170-a32d-b9ed7d112468/appgprj_6adf2c4fd9ec8191b6f1b79b16bdd2c1.git`
- 先前会话临时工作目录：`/workspace/scratch/2c8e34d3416f/layerlab/`（**并非当前环境可访问的固定目录**）

## 推荐恢复路线

1. 打开当初创建/更新这个 Site 的 ChatGPT 会话或 Sites 项目管理界面。
2. 使用该环境提供的**源码导出 / 下载项目 / repository clone** 功能；或让有该 Sites 项目读权限的代理把当前 V6 代码和 `public` 素材打成 ZIP。
3. 如果只能访问上面的私有 Git URL，先在拥有权限的环境申请**新鲜**的仓库读取凭据；历史工具返回的临时 token 不得复用，也不要写入聊天或 ZIP。
4. 导出**源码树**而非仅网页截图、静态页面包或浏览器里抓到的 JS bundle。必须包含项目根部配置、依赖锁文件、app/src/pages/components/lib、public/static、API 路由、构建和部署配置（以真实目录为准）。
5. 排除 `.env`、凭据、`.git` 私有令牌、`node_modules`、`.next`、dist/build 缓存和无必要日志（如果资产依赖这些目录必须另外说明）。
6. 将源代码 ZIP 放到本地 ChatGPT 的同一次对话中，与本交接包一起提供。

## 如何验证拿到的是“真正完整源码”

- 存在真实 `package.json` 或项目相应依赖清单。
- 存在源文件（例如 `.tsx`、`.ts`、`.jsx`、`.css`），不是只有编译后的静态 JS。
- 源文件中能定位此前 UI 工作室的 Icon 生成、AI 生图、主站 UI、活动 UI、拆层等模块。
- `public` 或相应 assets 目录有项目真正使用的图片、图标、字体引用（需遵守授权）。
- 在**不提交任何密钥**前提下，能够安装依赖并尝试构建；能记录启动错误。
- 与 V6 在线实际页面截图核对入口与核心功能。
- 用 `zip -T` 和 `unzip -l` 验证 ZIP 完整性；生成 SHA-256 清单。

## 当前缺少的材料

- 原站全部 TypeScript/JavaScript/React 或其他真实源码。
- `package.json`、lockfile、真实开发启动脚本。
- 实际服务端 API 源码与数据库/对象存储配置。
- 原站完整 `public/` 素材库、Figma 导出缓存、字体与许可证清单。
- 站点最新真实环境变量（这是必要保密的；只能提供名称/用途，不应进入压缩包）。

**注意：**此前会话有多份名为 UIStudio-* 的示例 ZIP，它们是页面示例或 PNG 集，不等于完整工程。不要误用这些文件覆盖真正源码。
